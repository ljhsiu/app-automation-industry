#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
交互式流程录制器模板
用法: python monitor_record.py <flow.yaml> <device_ip>
功能: 逐步引导操作设备，每步自动截图+抓取UI层级树
"""

import os, sys, time, json, subprocess, yaml, re
from pathlib import Path
from datetime import datetime

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# ADB 连接地址，可通过命令行参数或修改此处
DEVICE = sys.argv[2] if len(sys.argv) > 2 else "192.168.0.100:5555"


def adb(cmd: str, timeout: int = 15) -> str:
    r = subprocess.run(f"adb -s {DEVICE} {cmd}", shell=True,
                       capture_output=True, text=True, timeout=timeout)
    return (r.stdout + r.stderr).strip()


def capture_screenshot(save_path: str) -> bool:
    dev_path = "/sdcard/monitor_scr.png"
    adb(f"shell screencap -p {dev_path}")
    adb(f"pull {dev_path} \"{save_path}\"")
    adb(f"shell rm {dev_path}")
    return os.path.exists(save_path)


def capture_ui_hierarchy(save_path: str) -> bool:
    dev_path = "/sdcard/monitor_ui.xml"
    adb(f"shell uiautomator dump {dev_path}")
    adb(f"pull {dev_path} \"{save_path}\"")
    adb(f"shell rm {dev_path}")
    return os.path.exists(save_path)


def capture_activity() -> str:
    out = adb("shell dumpsys activity activities 2>/dev/null")
    for line in out.split("\n"):
        if "mResumedActivity" in line:
            return line.strip()
    return "unknown"


def main():
    flow_file = sys.argv[1] if len(sys.argv) > 1 else "flow.yaml"

    # 初始化
    print("=" * 60)
    print(f"  交互录制器 | 设备: {DEVICE}")
    print(f"  流程文件: {flow_file}")
    print("=" * 60)

    out = adb("shell echo OK")
    if "OK" not in out:
        print(f"  设备未连接: adb connect {DEVICE}")
        sys.exit(1)

    with open(flow_file, "r", encoding="utf-8") as f:
        flow = yaml.safe_load(f)
    steps = flow["steps"]
    total = len(steps)

    # 录制目录
    session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    session_dir = Path(f"./recording/{session_id}")
    ss_dir = session_dir / "screenshots"
    ui_dir = session_dir / "ui_hierarchy"
    ss_dir.mkdir(parents=True, exist_ok=True)
    ui_dir.mkdir(parents=True, exist_ok=True)

    observations = []
    print(f"\n  共 {total} 步，每步操作完成后按 Enter 录制\n")

    for i, step in enumerate(steps, 1):
        print(f"\n{'=' * 60}")
        print(f"  步骤 {i}/{total}: {step['id']} - {step['name']}")
        print(f"  {step['description']}")
        print(f"  预期: {step.get('expected', 'N/A')}")

        locs = step.get("locators", [])
        if locs:
            print(f"  定位:")
            for loc in locs:
                print(f"    - {loc['type']}: \"{loc['value']}\"")

        input(f"\n  完成操作后按 Enter...")

        # 截图
        ss_file = str(ss_dir / f"s{i:02d}_{step['id']}.png")
        ok_ss = capture_screenshot(ss_file)
        print(f"  截图 {'OK' if ok_ss else 'FAIL'}")

        # UI层级
        ui_file = str(ui_dir / f"s{i:02d}_{step['id']}.xml")
        ok_ui = capture_ui_hierarchy(ui_file)
        print(f"  UI树 {'OK' if ok_ui else 'FAIL'}")

        # Activity
        act = capture_activity()
        print(f"  Activity: {act[:100]}")

        # 反馈
        status = input(f"  结果 [ok/fail/skip]: ").strip().lower()
        if status in ("", "o"):
            status = "ok"
        note = input(f"  备注 (可选): ").strip()

        obs = {
            "step_id": step["id"], "step_name": step["name"],
            "screenshot": ss_file, "ui_hierarchy": ui_file,
            "activity": act, "status": status or "ok",
            "note": note or None,
        }

        # 文案差异收集
        for loc in locs:
            if loc["type"] == "text":
                actual = input(f"  文案 \"{loc['value']}\" 实际是? (回车=一致): ").strip()
                if actual:
                    obs[f"actual_text_{loc['value']}"] = actual

        observations.append(obs)

        if status in ("fail", "skip"):
            cont = input(f"  继续? [Y/n]: ").strip().lower()
            if cont in ("n", "no"):
                break

    # 保存记录
    report = {"session_id": session_id, "device": DEVICE, "observations": observations}
    with open(session_dir / "observations.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print(f"\n  录制完成: {session_dir}")
    print(f"  截图: {ss_dir}/")
    print(f"  UI层级: {ui_dir}/")


if __name__ == "__main__":
    main()

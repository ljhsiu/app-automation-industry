# 录制式脚本开发 — 关键技术教训

基于实际搬运压测脚本开发过程中积累的经验。

---

## 1. UI 元素定位策略

### text 定位优先于 resourceId

uiautomator2 的 `resourceId` 选择器在 `wait()` 时可能永远不返回（即使元素存在），
而 `text` 选择器更可靠。

```python
# 推荐
d(text="搬运").click()

# 不推荐（可能卡住）
d(resourceId="com.keenon.solutionindustry:id/view_bom").wait(timeout=30)
```

### child() 只查找直接子节点

`swipe_layout` → `view_root` → `left_shelf_text_area` → `tv_description`

```python
# 错误: child() 找不到孙子节点
sl.child(resourceId="...tv_description")  # -> 不存在

# 正确: 用 xpath 穿透任意层级
sl.xpath('.//*[@resource-id="...tv_description"]')  # -> 存在
```

### 正则解析 dump_hierarchy 作为兜底

当 uiautomator2 的 selector API 不可靠时，直接用正则解析 XML dump：

```python
xml = d.dump_hierarchy()
# 找到包含目标文案的 swipe_layout 片段
swipes = re.finditer(r'resource-id="...id/swipe_layout"[^>]*', xml)
for idx, m in enumerate(swipes):
    if "target_text" in xml[m.start():next_start]:
        # 点击第 idx 个
        d(resourceId="...id/swipe_layout", instance=idx).click()
```

### 浮窗/弹窗元素检查清单

进入浮窗后，先 dump 出所有 text 确认实际文案：

```python
xml = d.dump_hierarchy()
texts = set(re.findall(r'text="([^"]+)"', xml))
print(sorted(texts))  # 确认浮窗标题、按钮、选项的实际文案
```

---

## 2. 终端状态检测

### 多路径检测

不要只依赖一种终态判断，组合多种信号：

```python
# 主检测: tv_msg 元素文案
msg = d(resourceId="...tv_msg").get_text()
if "已完成卸货" in msg:      # 成功终态
    return "success"
if "匹配失败" in msg:        # 失败终态
    return "match_fail"

# 兜底: 底部按钮出现说明已进入终态
if d(text="确定").exists:
    msg2 = d(resourceId="...tv_msg").get_text()
    # 再次判断
```

### 状态机覆盖

完整的任务状态变换：
```
下发 → 正在前往A → 已到达A装货中 → 正在前往B → 已到达B卸货中
    → 已完成卸货 (成功)
    → 匹配失败    (失败，任意阶段)
    → 超时        (失败)
```

---

## 3. 编码与兼容性

### Windows GBK 编码

Windows 终端默认 GBK 编码无法输出 emoji，两种方案：

```python
# 方案A: 在脚本开头加入
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

# 方案B: 避免 emoji，用纯文本
print("[OK]")   # 而不是 ✅
print("[FAIL]")  # 而不是 ❌
```

运行前执行 `chcp 65001` 切换到 UTF-8 代码页。

---

## 4. 连接稳定性

### ADB 断连处理

机器人移动过程中 WiFi 可能断开，脚本需要处理：

```python
def connect(self) -> bool:
    import subprocess
    r = subprocess.run(f"adb connect {self.addr}", ...)
    if "connected" in r.stdout.lower():
        self.d = u2.connect(self.addr)
        return True
    return False
```

### 轮询中的异常保护

```python
while time.time() - t0 < timeout:
    try:
        msg = get_tv_msg(self.d)
    except Exception:  # 设备断连等
        time.sleep(interval)
        continue
```

---

## 5. 配置分离

所有可变参数从代码中抽取到 YAML 配置：

| 类型 | 示例 |
|------|------|
| 设备信息 | IP, 端口, 包名, Activity |
| 任务参数 | 起点, 终点, 货架规格, 超时 |
| UI定位 | 按钮文案, 资源ID, 浮窗标题 |
| 业务规则 | 最大连续失败次数, 轮间间隔 |

```yaml
transport:
  primary:
    start_point: "装卸点7"
    end_point: "装卸点8"
  shelf_spec:
    name: "1200"
    description: "1200 x 500"
    instance: 1
```

---

## 6. 失败熔断设计

```python
if res["status"] == "success":
    self.consecutive_fails = 0
    self.sp, self.ep = self.ep, self.sp  # 互换点位
else:
    self.consecutive_fails += 1
    if self.consecutive_fails >= self.max_fails:
        print("连续失败N次，停止压测")
        break
    # 点位不变，下一轮重试同一对
```
